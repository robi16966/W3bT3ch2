<!DOCTYPE html>
<html lang="sk">
<head>
<meta charset="UTF-8">
<title>First_Task</title>
<link rel="stylesheet" href="css1.css" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script src="script.js"></script>

</head>

<body>
<?php

echo "ZAPOCET1<br>";


?>

<form action="zap.php" method="post">
<input type="number" name="cislo"><br>
<input type="submit">
</form>

</body>

</html>