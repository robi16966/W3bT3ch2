<?php
	$Cislo = (int)$_POST['cislo'];
	//echo "<br>"."hop hop333333";
	echo $Cislo." -> GENEROVANE HESLA"."<br><br>";
	//$Cislo =10;
	
	//echo mt_rand(1,5);
	//echo mt_rand(1,5);
	$cislice="0123456789";
	$male_s="aeiouy";
	$velke_s="AEIOUY";
	$velke_sp="BCDFGHJKLMNPQRSTVXZ";
	$male_sp="bcdfghjklmnpqrstvxz";
	$heslo;
	$index;
	$bola_sp;
	for($i=0;$i<$Cislo;$i++)
	{
	for($j=0;$j<=9;$j++)	
	{
		$index=(int)mt_rand(1,5);
		if($bola_sp==1)
		{
			$bola_sp=0;
			$index=4;
		}
		//echo $index."<br>";
		if($index==1)
		{
		$heslo.=$male_s[mt_rand(0,strlen($male_s)-1)];
		continue;
		}
		if($index==2)
		{
		$heslo.=$velke_sp[mt_rand(0,strlen($velke_sp)-1)];
		$bola_sp=1;
		continue;
		}
		if($index==3)
		{
		$heslo.=$velke_s[mt_rand(0,strlen($velke_s)-1)];
		continue;
		}
		if($index==4)
		{
		$heslo.=$cislice[mt_rand(0,strlen($cislice)-1)];
		continue;
		
		}
		if($index==5){
		$heslo.=$male_sp[mt_rand(0,strlen($male_sp)-1)];
		$bola_sp=1;
		continue;
		}
		
	}
	echo $heslo;
	$heslo="";
	//echo "a";
	echo "<br>";
	}
	
	//$stack = array("orange", "banana");
//array_push($stack, "apple", "raspberry");
//echo $male[0];
//$paf.=$male[3];
//echo $heslo;



?>