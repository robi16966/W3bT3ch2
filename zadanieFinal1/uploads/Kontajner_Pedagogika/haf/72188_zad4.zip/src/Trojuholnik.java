import java.awt.Color;
import java.awt.Graphics;
import java.awt.Polygon;


public class Trojuholnik extends GeomTvar {
	private double dlzka;
	
	

	Trojuholnik(int x,int y,int r,int g,int b,double dlzka) {
			this.dlzka=dlzka;
			this.x=x;
			this.y=y;
			this.r=r;
			this.g=g;
			this.b=b;
	}

	
	public void vyp_obsah() {
		double Vc = dlzka*Math.sin(Math.PI/3);
		this.obsah=dlzka*Vc/2;
		
		
}

	public void vyp_obvod() {
		
	this.obvod=dlzka + dlzka + dlzka;

	
}
	
	
	public void paint(Graphics g){
		Polygon p=new Polygon();
		Color c=new Color(getR(),getG(),getB());
		g.setColor(c);
	
		//int[] x={getX()+(int)dlzka,getX(),getX()-(int)dlzka};int[] y={getX()+(int)dlzka,getY(),getY()+(int)dlzka};
		int[] x={this.x, (int)(this.x + this.dlzka), (int)((this.x + this.dlzka/2))};
		int[] y={this.y, this.y, (int)(this.y + Math.sqrt( Math.pow(this.dlzka,2) - Math.pow((this.dlzka/2),2) ))};
	
		p.xpoints=x;
		p.ypoints=y;
		p.npoints=x.length;
		g.drawPolygon(p);
		
		
		
		
		
	}

	
	

	
}