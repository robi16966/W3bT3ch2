import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

public class Platno extends Canvas{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<GeomTvar> list= new ArrayList<GeomTvar>();
	private double sucetObvodov=0;
	private double sucetObsahov=0;
	
	public Platno() { 
		 setBackground(Color.BLACK);  
	 		setSize(600,600);
	 		
	 		
	 		
	}
	
	public void paint(Graphics g)
	{
		for( GeomTvar gt : list)
		{
			gt.paint(g);
		}
	
	}
	
	
	 List<GeomTvar> getList() {
		return list;
	}
	public void setList(List<GeomTvar> list) {
		this.list = list;
	}
	public void addtoList(GeomTvar geomtvar) {
		this.list.add(geomtvar);
	}
	
	public void addtoList(GeomTvar[] geomtvar) {
		for(int i=0;i<geomtvar.length;i++)
		{
			this.list.add(geomtvar[i]);
		}
	}
		
	public void SetSucetObvodov(double obvod) {
			this.sucetObvodov=this.sucetObvodov+obvod;
		
		}
	public void SetSucetObsahov(double obsah) {	
	
	this.sucetObsahov=this.sucetObsahov+obsah;
	
	}
	
	public double GetSucetObvodov() {
		
	return this.sucetObvodov;
	}
	public double GetSucetObsahov() {	

		
		return this.sucetObsahov;
	}
	
	
	
}
	