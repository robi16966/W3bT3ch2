import java.awt.Color;
import java.awt.Graphics;

public class Stvorec extends GeomTvar {
	private double dlzka;
	
	

	Stvorec(int x,int y,int r,int g,int b,double dlzka) {
		this.dlzka=dlzka;
		this.x=x;
		this.y=y;
		this.r=r;
		this.g=g;
		this.b=b;
	}

	public void vyp_obsah() {
		
		this.obsah=dlzka*dlzka;
	
}

	public void vyp_obvod() {
	this.obvod=4*dlzka;
	
}
	
public void paint(Graphics g){
		
		Color c=new Color(getR(),getG(),getB());
		g.setColor(c);
	
		g.drawRect(getX(), getY(),(int)dlzka,(int)dlzka);
		
	}
	
}
