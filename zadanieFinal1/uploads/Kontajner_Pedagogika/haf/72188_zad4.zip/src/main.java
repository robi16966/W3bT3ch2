import java.io.IOException;

public class main{




	public static void main(String[] args) throws IOException {
		help a= new help();
		a.start(args[0]); 
		 
	}
	}
