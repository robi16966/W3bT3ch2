import java.awt.Graphics;

public abstract class GeomTvar {

	protected int x;
	protected int y;
	protected int r,g,b;
	protected double obvod,obsah;
	
	 abstract void vyp_obsah();
	 abstract void vyp_obvod();
	 abstract void paint(Graphics g);
	
	
	 
	
	public int getR() {
		return r;
	}
	public void setR(int r) {
		this.r = r;
	}
	public int getG() {
		return g;
	}
	public void setG(int g) {
		this.g = g;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public double getObvod() {
		return obvod;
	}
	public void setObvod(double obvod) {
		this.obvod = obvod;
	}
	public double getObsah() {
		return obsah;
	}
	public void setObsah(double obsah) {
		this.obsah = obsah;
	}	
}