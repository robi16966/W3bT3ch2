import java.awt.Color;
import java.awt.Graphics;

public class Kruh extends GeomTvar {
	
	
	private double polomer;
	
	Kruh(int x,int y,int r,int g,int b,double polomer) {
	this.polomer=polomer;	
	this.x=x;
	this.y=y;
	this.r=r;
	this.g=g;
	this.b=b;
	
	}
	

	public void vyp_obsah() {
		
		this.obsah=Math.PI*polomer*polomer;
}

	 public void vyp_obvod() {
		
	this.obvod=2*Math.PI*polomer;
	
}
	 
	 public void paint(Graphics g){
			
			Color c=new Color(getR(),getG(),getB());
			g.setColor(c);
		
			g.drawOval(getX(),getY(), (int)polomer, (int)polomer);
			
		}
		
	 
}
