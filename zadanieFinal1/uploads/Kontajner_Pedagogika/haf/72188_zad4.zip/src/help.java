
import java.awt.BorderLayout;

import java.awt.FileDialog;

import java.awt.Frame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;


import java.io.BufferedReader;
import java.io.BufferedWriter;

import java.io.FileInputStream;

import java.io.FileWriter;

import java.io.IOException;
import java.io.InputStreamReader;

import java.util.ArrayList;

public class help{ // pomocna trieda. pretoze  v triede main toto  nemoze byt...

	// potreboval som ich zadefinovat uz tu pretoze som mal problem pri vytvarani mouse listeneru.
	static MouseListener mouse;
	static ArrayList<String> ad = new ArrayList<String>(); // tu budem ukladat nove nakliknute geom tvary ktore potom zapisujem do suboru


	public static void start(String cesta) {
		String cesta1=cesta;
		String[] parts=readObsahZoSubora(cesta1).split("\n");
		double[][]cpp=Extract(parts);
		Platno platno=Vypocty(cpp);
		kreslenie(platno);
	}
	
	public static void kreslenie(Platno platno){ // v tejto metode vytvaram frame do ktoreho vkladam Canvas + buttony b1..b4 + uzmoznuje pridavat nove geom utvary na platno po kliknuti na obrazovku.
		
JFrame frame = new JFrame();
	
		frame.setTitle("Platno");
		frame.setSize(2100,740);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(platno);
	
		JButton b1 = new JButton("Kruh");
		JButton b2 = new JButton("Obldznik");
		JButton b3 = new JButton("Load");
		JButton b4 = new JButton("Save");
		
		// pre button b1 som si vyskusal trosku iny sposob pridania ActionListeneru ako pre b2,b3,b4. 
		ActionListener ctp =new ActionListener() {
		
		
			@Override
			public void actionPerformed(ActionEvent e) {
				platno.removeMouseListener(mouse);

			    mouse =new MouseListener()  {
				
				@Override
				public void mouseReleased(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mousePressed(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mouseExited(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mouseEntered(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mouseClicked(MouseEvent e) {
					String tmp="";
					int mouseX = e.getX();
					int mouseY = e.getY();
					GeomTvar cpp= new Kruh(mouseX, mouseY, 0, 230, 0, 20);
				tmp=tmp+"1"+";"+mouseX+";"+mouseY+";"+cpp.getR()+";"+cpp.getG()+";"+cpp.getB()+";"+"20"+";";
			ad.add(tmp);
				
					platno.addtoList(cpp);
					frame.add(platno);
					
				}
			};
			platno.addMouseListener(mouse);
	
			}
		};
		b1.addActionListener(ctp);
		
b2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				platno.removeMouseListener(mouse);	
			mouse = (new MouseListener() {
				
				@Override
				public void mouseReleased(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mousePressed(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mouseExited(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mouseEntered(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mouseClicked(MouseEvent e) {
					String tmp = "";
					int mouseX = e.getX();
					int mouseY = e.getY();
				
					GeomTvar cpp= new Obdlznik(mouseX, mouseY, 230, 0, 0, 20,50);
					tmp=tmp+"0"+";"+mouseX+";"+mouseY+";"+cpp.getR()+";"+cpp.getG()+";"+cpp.getB()+";"+"20"+";"+"50"+";";
					ad.add(tmp);
				
				
					platno.addtoList(cpp);
					frame.add(platno);
	
				}
			});
			platno.addMouseListener(mouse);
	
			}
		});

	b3.addActionListener( new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			platno.removeMouseListener(mouse);
			FileDialog fileDialog= new FileDialog(frame, "Choose a file", FileDialog.LOAD);
			fileDialog.setVisible(true);
			frame.dispose();
		
			start(fileDialog.getDirectory()+""+fileDialog.getFile());

			
		}
	});
	
	
	b4.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			platno.removeMouseListener(mouse);
			FileDialog fileDialog = new FileDialog(new Frame(), "Save", FileDialog.SAVE);
	        fileDialog.setVisible(true);
	        for(int i=0;i<ad.size();i++)
	        {
	        	try {
					wtf(fileDialog.getDirectory()+""+fileDialog.getFile(),ad.get(i));
				} catch (IOException e1) {
					e1.printStackTrace();
				}
	        }
			
		}
	});
		frame.add(b1,BorderLayout.NORTH);
		frame.add(b2,BorderLayout.SOUTH);
		frame.add(b3,BorderLayout.WEST);
		frame.add(b4,BorderLayout.EAST);
		frame.setVisible(true);
		
	}
	public static Platno Vypocty(double[][] cpp) { // v tejto medote vytvaram jednotlive objekty geom tvarov  pocitam obvody a obsahy pomocou metody tiedy Platno. jednotlive utvary pridavam do kolekcie geom utvarov.
		
		
		GeomTvar objekt;
		
		Platno platno=new Platno();
		
		String text="";
		int i;
		
		
		
		
		
		for(i=0;i<cpp.length;i++)
		{	int FirstNumber=(int)cpp[i][0];
			
			
				switch (FirstNumber)
				{
				case 0: objekt=new Obdlznik((int)cpp[i][1],(int)cpp[i][2],(int)cpp[i][3],(int)cpp[i][4],(int)cpp[i][5],cpp[i][cpp[i].length-2],cpp[i][cpp[i].length-1]); //polymorfizmus
									objekt.vyp_obsah();
									objekt.vyp_obvod();		
							platno.addtoList(objekt);
						platno.SetSucetObsahov(objekt.getObsah());
						platno.SetSucetObvodov(objekt.getObvod());
						break;
				case 1:	objekt=new Kruh((int)cpp[i][1],(int)cpp[i][2],(int)cpp[i][3],(int)cpp[i][4],(int)cpp[i][5],cpp[i][cpp[i].length-2]);//polymorfizmus
									objekt.vyp_obsah();
									objekt.vyp_obvod();
									
							platno.addtoList(objekt);
						platno.SetSucetObsahov(objekt.getObsah());
						platno.SetSucetObvodov(objekt.getObvod());
						break;
				case 2:	objekt=new Stvorec((int)cpp[i][1],(int)cpp[i][2],(int)cpp[i][3],(int)cpp[i][4],(int)cpp[i][5],cpp[i][cpp[i].length-2]);//polymorfizmus
									objekt.vyp_obsah();
									objekt.vyp_obvod();
									
							platno.addtoList(objekt);
						platno.SetSucetObsahov(objekt.getObsah());
						platno.SetSucetObvodov(objekt.getObvod());
						
						break;
				case 3: objekt=new Trojuholnik((int)cpp[i][1],(int)cpp[i][2],(int)cpp[i][3],(int)cpp[i][4],(int)cpp[i][5],cpp[i][cpp[i].length-2]);//polymorfizmus
								objekt.vyp_obsah();
								objekt.vyp_obvod();
							
							platno.addtoList(objekt);
						platno.SetSucetObsahov(objekt.getObsah());
						platno.SetSucetObvodov(objekt.getObvod());
						
						break;
				
				}
			
		}
		
		text=text +"n="+i+"\n"+"o="+platno.GetSucetObsahov()+"\n"+"s="+platno.GetSucetObvodov();
		System.out.println(text);
		return platno;
	}
	public static double[][] Extract(String[] parts)//v tejto metode ukladam cisla zo stringu do pola cpp
	{	double[][]cpp=new double[parts.length][8];// je tu 5 pretoze viem ze max pocet parametrov je 5 cisle (obdlznik)
	String regex = "[0-9]+";
		String[] tmp;
		String tmp1="";
		int tmp2;
		for(int i=0;i<parts.length;i++)
		{
			tmp=parts[i].split(";");// testujem ci vstupnom subore su len cisla a ziadne ine znaky okrem '-','.',';' ak ano program vypise chyby a skonci
			tmp1=parts[i].replace(";", "");
			tmp1=tmp1.replace(".", "");
			tmp1=tmp1.replace("-", "");
			if(tmp1.matches(regex)){
				;
				
			}
			
			else { System.out.println("3CHYBA pri naÄ�Ã­tanÃ­ Ãºtvarov. Skontrolujte vstupnÃ½ sÃºbor.");
			System.exit(0);
			}
			//..................................
			tmp2= Integer.parseInt(tmp[0]);

			switch (tmp2) // pomocou tohoto switchu testujem ci sedi pocet parametrov. pre jednotlive geom tvary.
		{
			case 0: if(tmp.length!=8){
				System.out.println("CHYBA pri naÄ�Ã­tanÃ­ Ãºtvarov. Skontrolujte vstupnÃ½ sÃºbor.");
				System.exit(0);
			}
			break;
			case 1: if(tmp.length!=7){
				System.out.println("CHYBA pri naÄ�Ã­tanÃ­ Ãºtvarov. Skontrolujte vstupnÃ½ sÃºbor.");
				System.exit(0);
			}
			break;
			case 2:
				if(tmp.length!=7){
					System.out.println("CHYBA pri naÄ�Ã­tanÃ­ Ãºtvarov. Skontrolujte vstupnÃ½ sÃºbor.");
					System.exit(0);
				}
				break;
			case 3:
				if(tmp.length!=7){
					System.out.println("CHYBA pri naÄ�Ã­tanÃ­ Ãºtvarov. Skontrolujte vstupnÃ½ sÃºbor.");
					System.exit(0);
				}
				break;
		}
			for(int j=0;j<tmp.length;j++)
			{	
				cpp[i][j]=Double.parseDouble(tmp[j]);
			}
		}
		
	
		
		return cpp;
	}
	public static void wtf(String cesta,String text) throws IOException{ //write to file
	    BufferedWriter writer = new BufferedWriter(new FileWriter(cesta, true));
	    writer.newLine();
	    writer.write(text);
	    writer.close();
	}

	public static String readObsahZoSubora(String a)

	{
	    String text="", tmp;
	    
	    try 
	    {
	        FileInputStream subor = new FileInputStream(a);
	        InputStreamReader in = new InputStreamReader(subor);
	        BufferedReader zoSuboru = new BufferedReader(in);               
	        while((tmp=zoSuboru.readLine())!=null){
	            text=text +tmp +"\n";
	        }
	        zoSuboru.close();
	    }
	    catch(Exception e)
	    {
	        System.out.println("CHYBA pri naÄ�Ã­tanÃ­ Ãºtvarov. Skontrolujte vstupnÃ½ sÃºbor.");
	        System.exit(1);
	    }  
	    
	    
	    
	    
	   return text;
	}
	public static void Kontrola_Vstupu(String text) 
	{
		 boolean containsDigit = false;
		
		if(text.length()<11){
			System.out.println("CHYBA pri naÄ�Ã­tanÃ­ Ãºtvarov. Skontrolujte vstupnÃ½ sÃºbor.");
			System.exit(0);
		}
		
		
		if(text.contains(";")==false){
			System.out.println("CHYBA pri naÄ�Ã­tanÃ­ Ãºtvarov. Skontrolujte vstupnÃ½ sÃºbor.");
			System.exit(0);
		}
		
		 
		        for (char c : text.toCharArray()) {
		            if (containsDigit = Character.isDigit(c)) {
		                break;
		            }
		        }
		    if(containsDigit)
		    ;
		    else{
				System.out.println("CHYBA pri naÄ�Ã­tanÃ­ Ãºtvarov. Skontrolujte vstupnÃ½ sÃºbor.");
				System.exit(0);
				
		    }
		    
		  
		    

	
	}
}
