import java.awt.Color;
import java.awt.Graphics;


public class Obdlznik extends GeomTvar {

	private double dlzka;
	private double sirka;
	
	
	Obdlznik(int x,int y,int r,int g,int b,double dlzka, double sirka) {
		this.dlzka=dlzka;
		this.sirka=sirka;
		this.x=x;
		this.y=y;	
		this.r=r;
		this.g=g;
		this.b=b;
	}

	public void vyp_obsah() {
		
		this.obsah=dlzka*sirka;
		
		
	}
	
	public void vyp_obvod() {
		this.obvod=2*dlzka+2*sirka;
		
	
	}
	
	public void paint(Graphics g){
		Color c=new Color(getR(),getG(),getB());
		g.setColor(c);
	
		g.drawRect(getX(), getY(),(int)sirka,(int)dlzka);
		
	}
	
}
